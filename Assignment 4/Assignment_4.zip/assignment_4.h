// Levi Mowery
// lemowery@mix.wvu.edu
// 800096308

#ifndef ASSIGNMENT_4_
#define ASSIGNMENT_4_

typedef struct Node{
  char* string;
  struct Node* next;
}Node;

typedef struct Queue{
  Node* front;
}Queue;

Queue* CreateQueue();
void DestroyQueue(Queue** q1);
void Enqueue(const char* str, Queue* q1);
char* Dequeue(Queue* q1);
Node* CreateNode(const char* str);

#endif
